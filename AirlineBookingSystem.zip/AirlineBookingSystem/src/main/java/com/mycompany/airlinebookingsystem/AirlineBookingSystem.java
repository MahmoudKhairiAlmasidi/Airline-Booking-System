/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.airlinebookingsystem;
import java.util.Scanner;
/**
 *
 * @author mahmoudkalmasidi
 */
public class AirlineBookingSystem {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int opition = 0;
        do{
            System.out.println("0) EXIT");
            System.out.println("1) Add A Book");
            System.out.println("2) Add A Passenger");
            System.out.println("3) Add A Employee");
            System.out.println("4) Add A Flight");
            System.out.println("5) Add A Private Aircraft");
            System.out.println("6) Add A Public Aircraft");
            System.out.println("7) Add A Airport");
            System.out.println("8) Add Company");
            opition = input.nextInt();
            if(opition == 1){
                int opition1 = 0;
                do{
                    System.out.println("0) RETURN");
                    System.out.println("1) First Class Ticket");
                    System.out.println("2) Business Ticket");
                    System.out.println("3) Economy Ticket");
                    opition1 = input.nextInt();
                    
                    if(opition1 == 1){
                        
                        String b, p, pn, d, a, de, ar, t;
                        int f, s, sC;
                        FirstClassTicket F;
                        System.out.println("Booking ID : ");
                        b = input.next();
                        System.out.println("Flight Number : ");
                        f = input.nextInt();
                        System.out.println("Passenger Passport Number : ");
                        p = input.next();
                        System.out.println("Passenger Name : ");
                        pn = input.next();
                        System.out.println("Seat Number : ");
                        s = input.nextInt();
                        System.out.println("Departure Time : ");
                        d = input.next();
                        System.out.println("Arrival Time : ");
                        a = input.next();
                        System.out.println("Departure City : ");
                        de = input.next();
                        System.out.println("Arrival City : ");
                        ar = input.next();
                        System.out.println("Ticket Class : ");
                        t = input.next();
                        System.out.println("Enter Number Of Seat You Want To Reserve");
                        sC = input.nextInt();
                        F = new FirstClassTicket(b, f, p, pn, s, d, a, de, ar, t, sC);
                        System.out.println("Your ticket has been booked");
                        
                        do{
                            System.out.println("0) RETURN");
                            System.out.println("1) Request Chauffeur Service");
                            System.out.println("2) Request Private Suite");
                            opition1 = input.nextInt();
                            if(opition1 == 1){
                            F.requestChauffeurService();
                            }                           
                            if(opition1 == 2){
                            F.requestPrivateSuite();
                            }
                        }while(opition1 != 0);
                    }
                    if(opition1 == 2){
                        
                        String b, p, pn, d, a, de, ar, t, m, l;
                        int f, s, sC;
                        BusinessTicket B;
                        System.out.println("Booking ID : ");
                        b = input.next();
                        System.out.println("Flight Number : ");
                        f = input.nextInt();
                        System.out.println("Passenger Passport Number : ");
                        p = input.next();
                        System.out.println("Passenger Name : ");
                        pn = input.next();
                        System.out.println("Seat Number : ");
                        s = input.nextInt();
                        System.out.println("Departure Time : ");
                        d = input.next();
                        System.out.println("Arrival Time : ");
                        a = input.next();
                        System.out.println("Departure City : ");
                        de = input.next();
                        System.out.println("Arrival City : ");
                        ar = input.next();
                        System.out.println("Ticket Class : ");
                        t = input.next();
                        System.out.println("Meal Opition : ");
                        m = input.next();
                        System.out.println("Loungr Access : ");
                        l = input.next();
                        System.out.println("Enter Number Of Seat You Want To Reserve");
                        sC = input.nextInt();
                        B = new BusinessTicket(m, l, b, f, p, pn, s, d, a, de, ar, t, sC);
                        System.out.println("Your ticket has been booked");
                        do{
                            System.out.println("0) RETURN");
                            System.out.println("1) Request Seat Upgrade");
                            System.out.println("2) Add Service");
                            opition1 = input.nextInt();
                            if(opition1 == 1){
                            B.requestSeatUpgrade();
                            }                           
                            if(opition1 == 2){
                                String Service;
                                System.out.println("Enter service : ");
                                Service = input.next();
                                B.addService(Service);
                                B.getService();
                            }
                        }while(opition1 != 0);
                        
                    }
                    if(opition1 == 3){
                        
                        String b, p, pn, d, a, de, ar, t;
                        int f, s, ba, sC;
                        EconomyTicket E;
                        System.out.println("Booking ID : ");
                        b = input.next();
                        System.out.println("Flight Number : ");
                        f = input.nextInt();
                        System.out.println("Passenger Passport Number : ");
                        p = input.next();
                        System.out.println("Passenger Name : ");
                        pn = input.next();
                        System.out.println("Seat Number : ");
                        s = input.nextInt();
                        System.out.println("Departure Time : ");
                        d = input.next();
                        System.out.println("Arrival Time : ");
                        a = input.next();
                        System.out.println("Departure City : ");
                        de = input.next();
                        System.out.println("Arrival City : ");
                        ar = input.next();
                        System.out.println("Ticket Class : ");
                        t = input.next();
                        System.out.println("Baggage Count : ");
                        ba = input.nextInt();
                        System.out.println("Enter Number Of Seat You Want To Reserve");
                        sC = input.nextInt();
                        E = new EconomyTicket(ba, b, f, p, pn, s, d, a, de, ar, t, sC);
                        System.out.println("Your ticket has been booked");
                        do{
                            System.out.println("0) RETURN");
                            System.out.println("1) Request Seat Upgrade");
                            System.out.println("2) Add Snack");
                            opition1 = input.nextInt();
                            if(opition1 == 1){
                            E.requestSeatUpgrade();
                            }                           
                            if(opition1 == 2){
                                String Snack;
                                System.out.println("Enter Snack : ");
                                Snack = input.next();
                                E.addSnack(Snack);
                                E.getSnack();
                                }
                            }while(opition1 != 0);
                           
                        }
                }
                while(opition1 != 0);
            }
            if(opition == 2){
                String n, g, na, b, pass;
                int a;
                Passenger p;
                System.out.println("Name : ");
                n = input.next();
                System.out.println("Gender : ");
                g = input.next();
                System.out.println("Nationality : ");
                na = input.next();
                System.out.println("BirthDate : ");
                b = input.next();
                System.out.println("Age : ");
                a = input.nextInt();
                System.out.println("Passport Number : ");
                pass = input.next();
                p = new Passenger(pass, n, g, na, b, a);
                p.viewDetails();
            }
            if(opition == 3){
                String n, g, na, b, j;
                int a, s;
                Employee E;
                System.out.println("Name : ");
                n = input.next();
                System.out.println("Gender : ");
                g = input.next();
                System.out.println("Nationality : ");
                na = input.next();
                System.out.println("BirthDate : ");
                b = input.next();
                System.out.println("Age : ");
                a = input.nextInt();
                System.out.println("Job Title : ");
                j = input.next();
                System.out.println("Salary : ");
                s = input.nextInt();
                E = new Employee(j, s, n, g, na, b, a);
                E.viewDetails();
            }
            if(opition == 4){
                String d, a, de, ar, fa;
                int c, av, f;
                Flight F;
                System.out.println("Flight Number : ");
                f = input.nextInt();
                System.out.println("Capacity : ");
                c = input.nextInt();
                System.out.println("Departure Time : ");
                d = input.next();
                System.out.println("Arrival Time : ");
                a = input.next();
                System.out.println("Departure City : ");
                de = input.next();
                System.out.println("Arrival City : ");
                ar = input.next();
                System.out.println("Flight Status : ");
                fa = input.next();
                System.out.println("Available Seat : ");
                av = input.nextInt();
                F = new Flight(f, c, d, a, de, ar, fa, av);
                F.viewDetails();
            }
            if(opition == 5){
                String t, m, tt;
                int c, a, f;
                boolean e;
                PublicAircraft P;
                System.out.println("Type : ");
                t = input.next();
                System.out.println("Capacity : ");
                c = input.nextInt();
                System.out.println("Average Speed : ");
                a = input.nextInt();
                System.out.println("Model : ");
                m = input.next();
                System.out.println("Fuel Level : ");
                f = input.nextInt();
                System.out.println("Engine Running : ");
                e = input.nextBoolean();
                System.out.println("Trip Type : ");
                tt = input.next();
                P = new PublicAircraft(tt, t, c, a, m, f, e);
                P.viewDetails();
            }
            if(opition == 6){
                String t, m, o, op;
                int c, a, f;
                boolean e;
                PrivateAircraft P;
                System.out.println("Type : ");
                t = input.next();
                System.out.println("Capacity : ");
                c = input.nextInt();
                System.out.println("Average Speed : ");
                a = input.nextInt();
                System.out.println("Model : ");
                m = input.next();
                System.out.println("Fuel Level : ");
                f = input.nextInt();
                System.out.println("Engine Running : ");
                e = input.nextBoolean();
                System.out.println("Owner Name : ");
                o = input.next();
                System.out.println("Owner Passport Number : ");
                op = input.next();
                P = new PrivateAircraft(o, op, t, c, a, m, f, e);
                P.viewDetails();
            }
            if(opition == 7){
                int opition7 = 0;
                String co, ci, cou;
                Airport A;
                System.out.println("Code : ");
                co = input.next();
                System.out.println("City : ");
                ci = input.next();
                System.out.println("Country : ");
                cou = input.next();
                A = new Airport(co, ci, cou);
                
                do{
                    System.out.println("0) RETURN");
                    System.out.println("1) Add Terminal");
                    System.out.println("2) Add Gate");
                    System.out.println("3) Remove Terminal");
                    opition7 = input.nextInt();
                    if(opition7 == 1){
                        String t;
                        System.out.println("Enter Terminal : ");
                        t = input.next();
                        A.addTerminal(t);
                    }
                    if(opition7 == 2){
                        String g;
                        System.out.println("Enter Gate : ");
                        g = input.next();
                        A.addGate(g);
                    }
                    if(opition7 == 3){
                        String t;
                        System.out.println("Enter Terminal : ");
                        t = input.next();
                        A.removeTerminal(t);
                    }
                    A.airportDetails();
                }while(opition7 != 0);
            }
            if(opition == 8){
                String n;
                System.out.println("Enter company name : ");
                n = input.next();
                int opition8 = 0;
            do{
                System.out.println("0) RETURN");
                System.out.println("1) Add A Book");
                System.out.println("2) Add A Passenger");
                System.out.println("3) Add A Employee");
                System.out.println("4) Add A Flight");
                System.out.println("5) Add A Private Aircraft");
                System.out.println("6) Add A Public Aircraft");
                System.out.println("7) Add A Airport");
                opition8 = input.nextInt();
                
                if(opition8 == 1){
                int opition1 = 0;
                do{
                    System.out.println("0) RETURN");
                    System.out.println("1) First Class Ticket");
                    System.out.println("2) Business Ticket");
                    System.out.println("3) Economy Ticket");
                    opition1 = input.nextInt();
                    
                    if(opition1 == 1){
                        
                        String b, p, pn, d, a, de, ar, t;
                        int f, s, sC;
                        FirstClassTicket F;
                        System.out.println("Booking ID : ");
                        b = input.next();
                        System.out.println("Flight Number : ");
                        f = input.nextInt();
                        System.out.println("Passenger Passport Number : ");
                        p = input.next();
                        System.out.println("Passenger Name : ");
                        pn = input.next();
                        System.out.println("Seat Number : ");
                        s = input.nextInt();
                        System.out.println("Departure Time : ");
                        d = input.next();
                        System.out.println("Arrival Time : ");
                        a = input.next();
                        System.out.println("Departure City : ");
                        de = input.next();
                        System.out.println("Arrival City : ");
                        ar = input.next();
                        System.out.println("Ticket Class : ");
                        t = input.next();
                        System.out.println("Enter Number Of Seat You Want To Reserve");
                        sC = input.nextInt();
                        F = new FirstClassTicket(b, f, p, pn, s, d, a, de, ar, t, sC);
                            System.out.println("Your ticker has been booked");
                         
                    }
                    if(opition1 == 2){
                        
                        String b, p, pn, d, a, de, ar, t, m, l;
                        int f, s, sC;
                        BusinessTicket B;
                        System.out.println("Booking ID : ");
                        b = input.next();
                        System.out.println("Flight Number : ");
                        f = input.nextInt();
                        System.out.println("Passenger Passport Number : ");
                        p = input.next();
                        System.out.println("Passenger Name : ");
                        pn = input.next();
                        System.out.println("Seat Number : ");
                        s = input.nextInt();
                        System.out.println("Departure Time : ");
                        d = input.next();
                        System.out.println("Arrival Time : ");
                        a = input.next();
                        System.out.println("Departure City : ");
                        de = input.next();
                        System.out.println("Arrival City : ");
                        ar = input.next();
                        System.out.println("Ticket Class : ");
                        t = input.next();
                        System.out.println("Meal Opition : ");
                        m = input.next();
                        System.out.println("Loungr Access : ");
                        l = input.next();
                        System.out.println("Enter Number Of Seat You Want To Reserve");
                        sC = input.nextInt();
                        B = new BusinessTicket(m, l, b, f, p, pn, s, d, a, de, ar, t, sC);
                        System.out.println("Your ticker has been booked");
                        
                    }
                    if(opition1 == 3){
                        
                        String b, p, pn, d, a, de, ar, t;
                        int f, s, ba, sC;
                        EconomyTicket E;
                        System.out.println("Booking ID : ");
                        b = input.next();
                        System.out.println("Flight Number : ");
                        f = input.nextInt();
                        System.out.println("Passenger Passport Number : ");
                        p = input.next();
                        System.out.println("Passenger Name : ");
                        pn = input.next();
                        System.out.println("Seat Number : ");
                        s = input.nextInt();
                        System.out.println("Departure Time : ");
                        d = input.next();
                        System.out.println("Arrival Time : ");
                        a = input.next();
                        System.out.println("Departure City : ");
                        de = input.next();
                        System.out.println("Arrival City : ");
                        ar = input.next();
                        System.out.println("Ticket Class : ");
                        t = input.next();
                        System.out.println("Baggage Count : ");
                        ba = input.nextInt();
                        System.out.println("Enter Number Of Seat You Want To Reserve");
                        sC = input.nextInt();
                        E = new EconomyTicket(ba, b, f, p, pn, s, d, a, de, ar, t, sC);
                        System.out.println("Your ticker has been booked");
                        
                     }
                }
                while(opition1 != 0);
            }
            if(opition8 == 2){
                String n1, g, na, b, pass;
                int a;
                Passenger p;
                System.out.println("Name : ");
                n1 = input.next();
                System.out.println("Gender : ");
                g = input.next();
                System.out.println("Nationality : ");
                na = input.next();
                System.out.println("BirthDate : ");
                b = input.next();
                System.out.println("Age : ");
                a = input.nextInt();
                System.out.println("Passport Number : ");
                pass = input.next();
                p = new Passenger(pass, n1, g, na, b, a);
                p.viewDetails();
            }
            if(opition8 == 3){
                String n2, g, na, b, j;
                int a, s;
                Employee E;
                System.out.println("Name : ");
                n2 = input.next();
                System.out.println("Gender : ");
                g = input.next();
                System.out.println("Nationality : ");
                na = input.next();
                System.out.println("BirthDate : ");
                b = input.next();
                System.out.println("Age : ");
                a = input.nextInt();
                System.out.println("Job Title : ");
                j = input.next();
                System.out.println("Salary : ");
                s = input.nextInt();
                E = new Employee(j, s, n2, g, na, b, a);
                E.viewDetails();
            }
            if(opition8 == 4){
                String d, a, de, ar, fa;
                int c, av, f;
                Flight F;
                System.out.println("Flight Number : ");
                f = input.nextInt();
                System.out.println("Capacity : ");
                c = input.nextInt();
                System.out.println("Departure Time : ");
                d = input.next();
                System.out.println("Arrival Time : ");
                a = input.next();
                System.out.println("Departure City : ");
                de = input.next();
                System.out.println("Arrival City : ");
                ar = input.next();
                System.out.println("Flight Status : ");
                fa = input.next();
                System.out.println("Available Seat : ");
                av = input.nextInt();
                F = new Flight(f, c, d, a, de, ar, fa, av);
                F.viewDetails();
            }
            if(opition8 == 5){
                String t, m, tt;
                int c, a, f;
                boolean e;
                PublicAircraft P;
                System.out.println("Type : ");
                t = input.next();
                System.out.println("Capacity : ");
                c = input.nextInt();
                System.out.println("Average Speed : ");
                a = input.nextInt();
                System.out.println("Model : ");
                m = input.next();
                System.out.println("Fuel Level : ");
                f = input.nextInt();
                System.out.println("Engine Running : ");
                e = input.nextBoolean();
                System.out.println("Trip Type : ");
                tt = input.next();
                P = new PublicAircraft(tt, t, c, a, m, f, e);
                P.viewDetails();
            }
            if(opition8 == 6){
                String t, m, o, op;
                int c, a, f;
                boolean e;
                PrivateAircraft P;
                System.out.println("Type : ");
                t = input.next();
                System.out.println("Capacity : ");
                c = input.nextInt();
                System.out.println("Average Speed : ");
                a = input.nextInt();
                System.out.println("Model : ");
                m = input.next();
                System.out.println("Fuel Level : ");
                f = input.nextInt();
                System.out.println("Engine Running : ");
                e = input.nextBoolean();
                System.out.println("Owner Name : ");
                o = input.next();
                System.out.println("Owner Passport Number : ");
                op = input.next();
                P = new PrivateAircraft(o, op, t, c, a, m, f, e);
                P.viewDetails();
            }
            if(opition8 == 7){
                int opition7 = 0;
                String co, ci, cou;
                Airport A;
                System.out.println("Code : ");
                co = input.next();
                System.out.println("City : ");
                ci = input.next();
                System.out.println("Country : ");
                cou = input.next();
                A = new Airport(co, ci, cou);
                
                do{
                    System.out.println("0) RETURN");
                    System.out.println("1) Add Terminal");
                    System.out.println("2) Add Gate");
                    System.out.println("3) Remove Terminal");
                    opition7 = input.nextInt();
                    if(opition7 == 1){
                        String t;
                        System.out.println("Enter Terminal : ");
                        t = input.next();
                        A.addTerminal(t);
                    }
                    if(opition7 == 2){
                        String g;
                        System.out.println("Enter Gate : ");
                        g = input.next();
                        A.addGate(g);
                    }
                    if(opition7 == 3){
                        String t;
                        System.out.println("Enter Terminal : ");
                        t = input.next();
                        A.removeTerminal(t);
                    }
                    A.airportDetails();
                }while(opition7 != 0);
            }
                }while(opition8 != 0);
            }
        }
        while(opition != 0);
    }
}
