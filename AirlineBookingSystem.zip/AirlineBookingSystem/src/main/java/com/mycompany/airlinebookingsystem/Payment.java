/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.airlinebookingsystem;

/**
 *
 * @author mahmoudkalmasidi
 */
public abstract class Payment {
    
    
    private String PaymentMethod;
    private int Amount;
    private String TransactionID;
    private String PaymentDate;
    private String PaymentStatus;
    private int No_reserved_flights;
    private double Balance;

    public Payment(String PaymentMethod, int Amount, String TransactionID, String PaymentDate, String PaymentStatus, int No_reserved_flights, double Balance) {
        this.PaymentMethod = PaymentMethod;
        this.Amount = Amount;
        this.TransactionID = TransactionID;
        this.PaymentDate = PaymentDate;
        this.PaymentStatus = PaymentStatus;
        this.No_reserved_flights = No_reserved_flights;
        this.Balance = Balance;
    }
     
    public String getPaymentMethod() {
        return PaymentMethod;
    }
    
    public void setPaymentMethod(String PaymentMethod) {
        this.PaymentMethod = PaymentMethod;
    }

    public int getAmount(){
        return Amount;
    }

    public void setAmount(int Amount) {
        this.Amount = Amount;
    }

    public String getTransactionID() {
        return TransactionID;
    }

    public void setTransactionID(String TransactionID) {
        this.TransactionID = TransactionID;
    }

    public String getPaymentDate() {
        return PaymentDate;
    }

    public void setPaymentDate(String PaymentDate) {
        this.PaymentDate = PaymentDate;
    }

    public String getPaymentStatus() {
        return PaymentStatus;
    }

    public void setPaymentStatus(String PaymentStatus) {
        this.PaymentStatus = PaymentStatus;
    }

    public int getNo_reserved_flights() {
        return No_reserved_flights;
    }

    public void setNo_reserved_flights(int No_reserved_flights) {
        this.No_reserved_flights = No_reserved_flights;
    }

    public double getBalance() {
        return Balance;
    }

    public void setBalance(double Balance) {
        this.Balance = Balance;
    }
   
    public void paymentCancel(){
     if(Balance < Amount)
         System.out.print("Insufficient balance for payment.");
    }
 
    public void paymentDetails() {
        System.out.println("Payment Method: " + PaymentMethod);
        System.out.println("Amount: " + Amount);
        System.out.println("Transaction ID: " + TransactionID);
        System.out.println("Payment Date: " + PaymentDate);
        System.out.println("Payment Status: " + PaymentStatus);
        System.out.println("Number of Reserved Flights: " + No_reserved_flights);
       
    }
    
    public void paymentProcess() {
        if (Balance >= Amount) {
            System.out.println("Payment successful.");
            PaymentStatus = "Paid";
        } else {
            System.out.println("Payment unsuccessful. Insufficient balance.");
            PaymentStatus = "Unpaid";
        }
    }
}