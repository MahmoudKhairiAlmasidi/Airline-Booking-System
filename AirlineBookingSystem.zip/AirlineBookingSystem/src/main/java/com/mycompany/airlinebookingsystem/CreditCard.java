/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.airlinebookingsystem;

/**
 *
 * @author mahmoudkalmasidi
 */
class CreditCard extends Payment {
    
    private int CardNumber;
    private String ExpiryDate;
    private int CVV ;
    private int CashBack ;

    public CreditCard(int CardNumber, String ExpiryDate, int CVV, int CashBack, String PaymentMethod, int Amount, String TransactionID, String PaymentDate, String PaymentStatus, int No_reserved_flights, double Balance) {
        super(PaymentMethod, Amount, TransactionID, PaymentDate, PaymentStatus, No_reserved_flights, Balance);
        this.CardNumber = CardNumber;
        this.ExpiryDate = ExpiryDate;
        this.CVV = CVV;
        this.CashBack = CashBack;
    }
    
    public int getCardNumber() {
        return CardNumber;
    }

    public void setCardNumber(int CardNumber) {
        this.CardNumber = CardNumber;
    }

    public String getExpiryDate() {
        return ExpiryDate;
    }

    public void setExpiryDate(String ExpiryDate) {
        this.ExpiryDate = ExpiryDate;
    }

    public int getCvv() {
        return CVV;
    }


    public int getCashback() {
        return CashBack;
    }

    public void setCashback(int CashBack) {
        this.CashBack = CashBack;
    }

    public void award() {
        if ("credit card".equals(getPaymentMethod()) && getNo_reserved_flights() >= 2) { CashBack++; }
    }
            
    public void checkCVV(int CVV) {
        if (String.valueOf(CVV).length() != 3) 
            System.out.println("CVV must be a 3 digit number.");
        else  this.CVV = CVV;
  }
}