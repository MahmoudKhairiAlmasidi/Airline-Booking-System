/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.airlinebookingsystem;
import java.util.ArrayList;
/**
 *
 * @author mahmoudkalmasidi
 */
public class BusinessTicket extends Booking implements AirlineBooking {
    private String MealOpition;
    private String LoungeAccess;
    private ArrayList Service = new ArrayList<String>();
    private boolean SeatUpgrade;

    public BusinessTicket(String MealOpition, String LoungeAccess, String BookingID, int FlightNumber, String PassengerPassportNumber, String PassengerName, int SeatNumber, String DepartureTime, String ArrivalTime, String DepartureCity, String ArrivalCity, String TicketClass, int seatCount) {
        super(BookingID, FlightNumber, PassengerPassportNumber, PassengerName, SeatNumber, DepartureTime, ArrivalTime, DepartureCity, ArrivalCity, TicketClass, seatCount);
        this.MealOpition = MealOpition;
        this.LoungeAccess = LoungeAccess;
    }
    
    public String getMealOpition() {
        return MealOpition;
    }

    public void setMealOpition(String MealOpition) {
        this.MealOpition = MealOpition;
    }

    public String getLoungeAccess() {
        return LoungeAccess;
    }

    public void setLoungeAccess(String LoungeAccess) {
        this.LoungeAccess = LoungeAccess;
    }

    public ArrayList getService() {
        return Service;
    }
    
    
    
    public void addService(String s){
        Service.add(s);
        System.out.println("Service has been added.");
    }
    public void ticketType() {
        System.out.println("Business Ticket.");
    }
    public void requestSeatUpgrade(){
        System.out.println("Your request has been executed.");
        SeatUpgrade = true;
    }
}
