/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.airlinebookingsystem;

/**
 *
 * @author mahmoudkalmasidi
 */
public class Destination implements AirlineBooking {
    private String Name;
    private int Code;

    public Destination(String Name, int Code) {
        this.Name = Name;
        this.Code = Code;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public int getCode() {
        return Code;
    }

    public void setCode(int Code) {
        this.Code = Code;
    }
    
    public void changeDestination(String Name, int Code) {
        this.Name = Name;
        this.Code = Code;
        System.out.println("Destination details updated successfully.");
    }
    public void availableDestination() {
        System.out.println("Dubai");
        System.out.println("Doha");
        System.out.println("Paris");
        System.out.println("Makkah");
        System.out.println("New York");
        System.out.println("Cairo");
    }
    public void viewDetails() {
        System.out.println("Destination name : " + Name);
        System.out.println("Destination code : " + Code);
    }
}
