/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.airlinebookingsystem;

/**
 *
 * @author mahmoudkalmasidi
 */
public class Route {
    private String DepartureAirport;
    private String ArrivalAirport;
    private double Distance;
    private String DepartureTime;

    public Route(String DepartureAirport, String ArrivalAirport, double Distance, String DepartureTime) {
        this.DepartureAirport = DepartureAirport;
        this.ArrivalAirport = ArrivalAirport;
        this.Distance = Distance;
        this.DepartureTime = DepartureTime;
    }

    public String getDepartureAirport() {
        return DepartureAirport;
    }

    public void setDepartureAirport(String DepartureAirport) {
        this.DepartureAirport = DepartureAirport;
    }

    public String getArrivalAirport() {
        return ArrivalAirport;
    }

    public void setArrivalAirport(String ArrivalAirport) {
        this.ArrivalAirport = ArrivalAirport;
    }

    public double getDistance() {
        return Distance;
    }

    public void setDistance(double Distance) {
        this.Distance = Distance;
    }

    public String getDepartureTime() {
        return DepartureTime;
    }

    public void setDepartureTime(String DepartureTime) {
        this.DepartureTime = DepartureTime;
    }
    
    public void getSpeed(){
        System.out.println("The flight speed 860KM.");
    }
    public void petrolConsumption(){
        System.out.println("The flight petrol consumption. 1200L.");
    }
}
