/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.airlinebookingsystem;

/**
 *
 * @author mahmoudkalmasidi
 */
public class BankTransfer extends Payment {
    
    private String BankName;
    private String AccountNumber;

    public BankTransfer(String BankName, String AccountNumber, String PaymentMethod, int Amount, String TransactionID, String PaymentDate, String PaymentStatus, int No_reserved_flights, double Balance) {
        super(PaymentMethod, Amount, TransactionID, PaymentDate, PaymentStatus, No_reserved_flights, Balance);
        this.BankName = BankName;
        this.AccountNumber = AccountNumber;
    }

    public String getBankName() {
        return BankName;
    }

    public void setBankName(String bankName) {
        this.BankName = bankName;
    }

    public String getAccountNumber() {
        return AccountNumber;
    }

    public void setAccountNumber(String AccountNumber) {
        this.AccountNumber = AccountNumber;
    }

    public double calcTax() {
        return getAmount() * 0.1;
    }

}

