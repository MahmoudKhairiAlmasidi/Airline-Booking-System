/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.airlinebookingsystem;
import java.util.ArrayList;
/**
 *
 * @author mahmoudkalmasidi
 */
public class Airport {
    private ArrayList Terminal = new ArrayList <String>();
    private ArrayList Gate = new ArrayList <String>();
    private String Code;
    private String City;
    private String Country;

    public Airport(String Code, String City, String Country) {
        this.Code = Code;
        this.City = City;
        this.Country = Country;
    }

    public ArrayList getTerminal() {
        return Terminal;
    }

    public void setTerminal(ArrayList Terminal) {
        this.Terminal = Terminal;
    }

    public ArrayList getGate() {
        return Gate;
    }

    public void setGate(ArrayList Gate) {
        this.Gate = Gate;
    }

    public String getCode() {
        return Code;
    }

    public void setCode(String Code) {
        this.Code = Code;
    }

    public String getCity() {
        return City;
    }

    public void setCity(String City) {
        this.City = City;
    }

    public String getCountry() {
        return Country;
    }

    public void setCountry(String Country) {
        this.Country = Country;
    }
    
    public void airportDetails() {
        System.out.println("Terminals : " + getTerminal());
        System.out.println("Code : " + Code);
        System.out.println("City : " + City);
        System.out.println("Country : " + Country);
        System.out.println("Gates : " + getGate());
    }
    public void addTerminal(String t) {
        Terminal.add(t);
    }
    public void removeTerminal(String t) {
        Terminal.remove(t);
    }
    public void addGate(String g) {
        Gate.add(g);
    }
}
