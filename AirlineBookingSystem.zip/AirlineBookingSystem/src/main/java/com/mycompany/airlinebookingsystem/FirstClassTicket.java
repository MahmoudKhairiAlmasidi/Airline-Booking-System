/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.airlinebookingsystem;

/**
 *
 * @author mahmoudkalmasidi
 */
public class FirstClassTicket extends Booking implements AirlineBooking {
    private boolean PrivateSuite;
    private boolean ChauffeurService;

    public FirstClassTicket(String BookingID, int FlightNumber, String PassengerPassportNumber, String PassengerName, int SeatNumber, String DepartureTime, String ArrivalTime, String DepartureCity, String ArrivalCity, String TicketClass, int seatCount) {
        super(BookingID, FlightNumber, PassengerPassportNumber, PassengerName, SeatNumber, DepartureTime, ArrivalTime, DepartureCity, ArrivalCity, TicketClass, seatCount);
        this.PrivateSuite = false;
        this.ChauffeurService = false;
    }

    public boolean isPrivateSuite() {
        return PrivateSuite;
    }

    public void setPrivateSuite(boolean PrivateSuite) {
        this.PrivateSuite = PrivateSuite;
    }

    public boolean isChauffeurService() {
        return ChauffeurService;
    }

    public void setChauffeurService(boolean ChauffeurService) {
        this.ChauffeurService = ChauffeurService;
    }

    
    
    public void ticketType() {
        System.out.println("First Class Ticket.");
    }
    public void changeFlight(int New) {
    
        System.out.println("Flight chande from " + getFlightNumber() + " to " + New);
        setFlightNumber(New);
    }
    public void requestChauffeurService() {
        System.out.println("Your request has been executed.");
        setChauffeurService(true);
    }
    public void requestPrivateSuite() {
        System.out.println("Your request has been executed.");
        setPrivateSuite(true);
    }
}
