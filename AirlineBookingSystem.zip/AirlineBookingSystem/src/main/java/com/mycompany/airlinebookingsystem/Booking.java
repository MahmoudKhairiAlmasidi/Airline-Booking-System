/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.airlinebookingsystem;

/**
 *
 * @author mahmoudkalmasidi
 */
public abstract class Booking {
    private String BookingID;
    private int FlightNumber;
    private String PassengerPassportNumber;
    private String PassengerName;
    private int SeatNumber;
    private String DepartureTime;
    private String ArrivalTime;
    private String DepartureCity;
    private String ArrivalCity;
    private String TicketClass;
    private int seatCount;
    private int Count = 0;

    
    public Booking(String BookingID, int FlightNumber, String PassengerPassportNumber, String PassengerName, int SeatNumber, String DepartureTime, String ArrivalTime, String DepartureCity, String ArrivalCity, String TicketClass, int seatCount) {
        this.BookingID = BookingID;
        this.FlightNumber = FlightNumber;
        this.PassengerPassportNumber = PassengerPassportNumber;
        this.PassengerName = PassengerName;
        this.SeatNumber = SeatNumber;
        this.DepartureTime = DepartureTime;
        this.ArrivalTime = ArrivalTime;
        this.DepartureCity = DepartureCity;
        this.ArrivalCity = ArrivalCity;
        this.TicketClass = TicketClass;
        this.seatCount = seatCount;
        ++Count;
    }

    public void setFlightNumber(int FlightNumber) {
        this.FlightNumber = FlightNumber;
    }

    public void setPassengerPassportNumber(String PassengerPassportNumber) {
        this.PassengerPassportNumber = PassengerPassportNumber;
    }

    public void setPassengerName(String PassengerName) {
        this.PassengerName = PassengerName;
    }

    public void setSeatNumber(int SeatNumber) {
        this.SeatNumber = SeatNumber;
    }

    public void setDepartureTime(String DepartureTime) {
        this.DepartureTime = DepartureTime;
    }

    public void setArrivalTime(String ArrivalTime) {
        this.ArrivalTime = ArrivalTime;
    }

    public void setDepartureCity(String DepartureCity) {
        this.DepartureCity = DepartureCity;
    }

    public void setArrivalCity(String ArrivalCity) {
        this.ArrivalCity = ArrivalCity;
    }

    public void setTicketClass(String TicketClass) {
        this.TicketClass = TicketClass;
    }

    public int getFlightNumber() {
        return FlightNumber;
    }

    public String getPassengerPassportNumber() {
        return PassengerPassportNumber;
    }

    public String getPassengerName() {
        return PassengerName;
    }

    public int getSeatNumber() {
        return SeatNumber;
    }

    public String getDepartureTime() {
        return DepartureTime;
    }

    public String getArrivalTime() {
        return ArrivalTime;
    }

    public String getDepartureCity() {
        return DepartureCity;
    }

    public String getArrivalCity() {
        return ArrivalCity;
    }

    public String getTicketClass() {
        return TicketClass;
    }

    public String getBookingID() {
        return BookingID;
    }

    public void setBookingID(String BookingID) {
        this.BookingID = BookingID;
    }

    public int getTicketCount() {
        return Count;
    }
    
    public abstract void ticketType();
    public void viewDetails(){
        System.out.println("Passenger Name : " + PassengerName);
        System.out.println("Passenger Passport Number : " + PassengerPassportNumber);
        System.out.println("Flight Number : " + FlightNumber);
        System.out.println("Seat Number : " + SeatNumber);
        System.out.println("Departure Time : " + DepartureTime);
        System.out.println("Arrival Time : " + ArrivalTime);
        System.out.println("Departure City : " + DepartureCity);
        System.out.println("Arrival City : " + ArrivalCity);
        System.out.println("Ticket Class : " + TicketClass);
    }
    public void passengerInfo() {
        System.out.println("Passenger Name : " + PassengerName);
        System.out.println("Passenger Passport Number : " + PassengerPassportNumber);
    }
    public void cancelTicket() {
        System.out.println("Booking with ID " + BookingID + " has been updated.");
        --Count;
    }
    public void updateTicket(int FlightNumber, String PassengerPassportNumber, String PassengerName, int SeatNumber, String DepartureTime, String ArrivalTime, String DepartureCity, String ArrivalCity) {
        this.FlightNumber = FlightNumber;
        this.PassengerPassportNumber = PassengerPassportNumber;
        this.PassengerName = PassengerName;
        this.SeatNumber = SeatNumber;
        this.DepartureTime = DepartureTime;
        this.ArrivalTime = ArrivalTime;
        this.DepartureCity = DepartureCity;
        this.ArrivalCity = ArrivalCity;
        System.out.println("Booking with ID " + BookingID + " has been updated.");
    }

}
