/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.airlinebookingsystem;

import java.util.ArrayList;

/**
 *
 * @author mahmoudkalmasidi
 */
public class Aircraft {
    private String type;
    private int capacity;
    private int averageSpeed;
    private String model;
    private int fuelLevel;
    private boolean engineRunning;
    private boolean isFlying;
    

    public static ArrayList<Aircraft> onGroundAircraftList = new ArrayList<>();
    
    public Aircraft(String type, int capacity, int averageSpeed, String model, int fuelLevel, boolean engineRunning) {
        this.type = type;
        this.capacity = capacity;
        this.averageSpeed = averageSpeed;
        this.model = model;
        this.fuelLevel = fuelLevel;
        this.engineRunning = engineRunning;
        this.isFlying = false;
    }
    
     public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public int getAverageSpeed() {
        return averageSpeed;
    }

    public void setAverageSpeed(int averageSpeed) {
        this.averageSpeed = averageSpeed;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getFuelLevel() {
        return fuelLevel;
    }

    public void setFuelLevel(int fuelLevel) {
        this.fuelLevel = fuelLevel;
    }

    public boolean isEngineRunning() {
        return engineRunning;
    }

    public void setEngineRunning(boolean engineRunning) {
        this.engineRunning = engineRunning;
    }
 public boolean isFlying() {
        return isFlying;
    }

    public void setFlying(boolean flying) {
        isFlying = flying;
    }
   
    public void startEngine() {
        if (!engineRunning) {
            engineRunning = true;
            System.out.println("Engine started.");
        } else {
            System.out.println("Engine is already running.");
        }
    }

    public void takeoff() {
        if (engineRunning && fuelLevel > 0) {
            isFlying = true; // Update isFlying status when taking off
            System.out.println("Taking off.");
        } else {
            System.out.println("Cannot take off. Engine not running or low fuel.");
        }
    }
    public void refuel(int amount) {
        fuelLevel += amount;
        System.out.println("Fuel level after refueling: " + fuelLevel);
    }

    
}

