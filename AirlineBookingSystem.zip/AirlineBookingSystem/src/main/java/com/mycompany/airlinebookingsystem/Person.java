/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.airlinebookingsystem;

/**
 *
 * @author mahmoudkalmasidi
 */
public abstract class Person {
    private String Name;
    private String Gender;
    private String Nationality;
    private String BirthDate;
    private int Age;

    public Person(){}
    public Person(String Name, String Gender, String Nationality, String BirthDate, int Age) {
        this.Name = Name;
        this.Gender = Gender;
        this.Nationality = Nationality;
        this.BirthDate = BirthDate;
        this.Age = Age;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public void setGender(String Gender) {
        this.Gender = Gender;
    }

    public void setNationality(String Nationality) {
        this.Nationality = Nationality;
    }

    public void setBirthDate(String BirthDate) {
        this.BirthDate = BirthDate;
    }

    public void setAge(int Age) {
        this.Age = Age;
    }

    public String getName() {
        return Name;
    }

    public String getGender() {
        return Gender;
    }

    public String getNationality() {
        return Nationality;
    }

    public String getBirthDate() {
        return BirthDate;
    }

    public int getAge() {
        return Age;
    }
    
    public abstract void viewDetails();
}
