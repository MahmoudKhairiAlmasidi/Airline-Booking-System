/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.airlinebookingsystem;
import java.util.ArrayList;
/**
 *
 * @author mahmoudkalmasidi
 */
public class Employee extends Person implements AirlineBooking{
    private String JobTitle;
    private int Salary;
    private ArrayList Flight = new ArrayList <Flight>();

    public Employee(String JobTitle, int Salary, String Name, String Gender, String Nationality, String BirthDate, int Age) {
        super(Name, Gender, Nationality, BirthDate, Age);
        this.JobTitle = JobTitle;
        this.Salary = Salary;
    }

    public String getJobTitle() {
        return JobTitle;
    }

    public void setJobTitle(String JobTitle) {
        this.JobTitle = JobTitle;
    }

    public int getSalary() {
        return Salary;
    }

    public void setSalary(int Salary) {
        this.Salary = Salary;
    }

    public ArrayList getFlight() {
        return Flight;
    }

    public void setFlight(ArrayList Flight) {
        this.Flight = Flight;
    }
    
    public void addFlight(Flight F) {
        Flight.add(F);
    }
    public void removeFlight(Flight f) {
        Flight.remove(f);
    }
    public void updateFlight(String JobTitle, int Salary, String Name, String Gender, String Nationality, String BirthDate, int Age) {
       this.JobTitle = JobTitle;
        this.Salary = Salary;
        System.out.println("Flight details updated successfully.");
    }
    public void generateReport() {
        System.out.println("Report generated successfully.");
    }
    public void viewDetails() {
        System.out.println("Employee Name : " + getName());
        System.out.println("Employee Gender : " + getGender());
        System.out.println("Employee Nationality : " + getNationality());
        System.out.println("Employee BirthDate : " + getBirthDate());
        System.out.println("Employee Age : " + getAge());
        System.out.println("Employee JobTitle : " + JobTitle);
        System.out.println("Employee Salary : " + Salary);
    }
}
