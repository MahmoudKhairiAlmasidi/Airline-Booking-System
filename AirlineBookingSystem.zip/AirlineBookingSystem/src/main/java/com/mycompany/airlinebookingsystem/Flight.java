/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.airlinebookingsystem;
import java.util.ArrayList;
/**
 *
 * @author mahmoudkalmasidi
 */
public class Flight implements AirlineBooking {
    private int FlightNumber;
    private int Capacity;
    private String DepartureTime;
    private String ArrivalTime;
    private String DepartureCity;
    private String ArrivalCity;
    private ArrayList PassengerList = new ArrayList<String>();
    private ArrayList Book = new ArrayList<Booking>();
    private String FlightStatus;
    private int AvailableSeat;
    private int Count = 0;

    public Flight(int FlightNumber, int Capacity, String DepartureTime, String ArrivalTime, String DepartureCity, String ArrivalCity, String FlightStatus, int AvailableSeat) {
        this.FlightNumber = FlightNumber;
        this.Capacity = Capacity;
        this.DepartureTime = DepartureTime;
        this.ArrivalTime = ArrivalTime;
        this.DepartureCity = DepartureCity;
        this.ArrivalCity = ArrivalCity;
        this.FlightStatus = FlightStatus;
        this.AvailableSeat = AvailableSeat;
        ++Count;
    }

    public int getFlightNumber() {
        return FlightNumber;
    }

    public void setFlightNumber(int FlightNumber) {
        this.FlightNumber = FlightNumber;
    }

    public int getCapacity() {
        return Capacity;
    }

    public void setCapacity(int Capacity) {
        this.Capacity = Capacity;
    }

    public String getDepartureTime() {
        return DepartureTime;
    }

    public void setDepartureTime(String DepartureTime) {
        this.DepartureTime = DepartureTime;
    }

    public String getArrivalTime() {
        return ArrivalTime;
    }

    public void setArrivalTime(String ArrivalTime) {
        this.ArrivalTime = ArrivalTime;
    }

    public String getDepartureCity() {
        return DepartureCity;
    }

    public void setDepartureCity(String DepartureCity) {
        this.DepartureCity = DepartureCity;
    }

    public String getArrivalCity() {
        return ArrivalCity;
    }

    public void setArrivalCity(String ArrivalCity) {
        this.ArrivalCity = ArrivalCity;
    }

    public ArrayList getPassengerList() {
        return PassengerList;
    }

    public void setPassengerList(ArrayList PassengerList) {
        this.PassengerList = PassengerList;
    }

    public ArrayList getBook() {
        return Book;
    }

    public void setBook(ArrayList Book) {
        this.Book = Book;
    }

    public String getFlightStatus() {
        return FlightStatus;
    }

    public void setFlightStatus(String FlightStatus) {
        this.FlightStatus = FlightStatus;
    }

    public int getAvailableSeat() {
        return AvailableSeat;
    }

    public void setAvailableSeat(int AvailableSeat) {
        this.AvailableSeat = AvailableSeat;
    }

    public int getFlightCount() {
        return Count;
    }
    
    public void bookFlight(Booking b) {
        Book.add(b);
        AvailableSeat--;
    }
    public void cancelFlight(Booking b) {
        b.cancelTicket();
        Book.remove(b);
    }
    public void viewDetails() {
        System.out.println("Flight Number : " + FlightNumber);
        System.out.println("Capacity : " + Capacity);
        System.out.println("Departure Time : " + DepartureTime);
        System.out.println("Arrival Time : " + ArrivalTime);
        System.out.println("Departure City : " + DepartureCity);
        System.out.println("Arrival City : " + ArrivalCity);
        System.out.println("Flight Status : " + FlightStatus);
        System.out.println("Available Seat : " + AvailableSeat);
    }
    public void updateFlightInformation(int FlightNumber, int Capacity, String DepartureTime, String ArrivalTime, String DepartureCity, String ArrivalCity, String FlightStatus, int AvailableSeat){
        this.FlightNumber = FlightNumber;
        this.Capacity = Capacity;
        this.DepartureTime = DepartureTime;
        this.ArrivalTime = ArrivalTime;
        this.DepartureCity = DepartureCity;
        this.ArrivalCity = ArrivalCity;
        this.FlightStatus = FlightStatus;
        this.AvailableSeat = AvailableSeat;
        System.out.println("Flight details updated successfully.");
    }
    public void isFlightFull(){
        if(AvailableSeat == 0) System.out.println("Flight is full.");
    }
    
}   
