/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.airlinebookingsystem;

/**
 *
 * @author mahmoudkalmasidi
 */
public class PrivateAircraft extends Aircraft implements AirlineBooking {
    private String OwnerName;
    private String OwnerPassNumb;

    public PrivateAircraft(String OwnerName, String OwnerPassNumb, String type, int capacity, int averageSpeed, String model, int fuelLevel, boolean engineRunning) {
        super(type, capacity, averageSpeed, model, fuelLevel, engineRunning);
        this.OwnerName = OwnerName;
        this.OwnerPassNumb = OwnerPassNumb;
    }

    public String getOwnerName() {
        return OwnerName;
    }

    public void setOwnerName(String OwnerName) {
        this.OwnerName = OwnerName;
    }

    public String getOwnerPassNumb() {
        return OwnerPassNumb;
    }

    public void setOwnerPassNumb(String OwnerPassNumb) {
        this.OwnerPassNumb = OwnerPassNumb;
    }
    
    @Override
    public void viewDetails() {
        System.out.println("Aircraft model : " + getModel());
        System.out.println("Aircraft Capacity : " + getCapacity());
        System.out.println("Aircraft Average Speed : " + getAverageSpeed());
        System.out.println("Aircraft Owner Name : " + OwnerName);
        System.out.println("Aircraft Owner passport number : " + OwnerPassNumb);
    }
    
}
