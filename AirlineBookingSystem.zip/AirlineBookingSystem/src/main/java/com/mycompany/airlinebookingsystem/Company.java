/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.airlinebookingsystem;

import java.util.ArrayList;

/**
 *
 * @author mahmoudkalmasidi
 */
public class Company {
    private String Name;
    private ArrayList Passenger = new ArrayList <Passenger>();
    private ArrayList Employee = new ArrayList <Employee>();
    private ArrayList Flight = new ArrayList <Flight>();
    private ArrayList PrivateAircraft = new ArrayList <PrivateAircraft>();
    private ArrayList PublicAircraft = new ArrayList <PublicAircraft>();
    private ArrayList Airport = new ArrayList <Airport>();
    private ArrayList FirstClassTicket = new ArrayList <FirstClassTicket>();
    private ArrayList BusinessTicket = new ArrayList <BusinessTicket>();
    private ArrayList EconomyTicket = new ArrayList <EconomyTicket>();

    public Company(String Name) {
        this.Name = Name;
    }

    public String getName() {
        return Name;
    }

    public ArrayList getPassenger() {
        return Passenger;
    }

    public ArrayList getEmployee() {
        return Employee;
    }

    public ArrayList getFlight() {
        return Flight;
    }

    public ArrayList getPrivateAircraft() {
        return PrivateAircraft;
    }

    public ArrayList getPublicAircraft() {
        return PublicAircraft;
    }

    public ArrayList getAirport() {
        return Airport;
    }

    public ArrayList getFirstClassTicket() {
        return FirstClassTicket;
    }

    public ArrayList getBusinessTicket() {
        return BusinessTicket;
    }

    public ArrayList getEconomyTicket() {
        return EconomyTicket;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public void setPassenger(ArrayList Passenger) {
        this.Passenger = Passenger;
    }

    public void setEmployee(ArrayList Employee) {
        this.Employee = Employee;
    }

    public void setFlight(ArrayList Flight) {
        this.Flight = Flight;
    }

    public void setPrivateAircraft(ArrayList PrivateAircraft) {
        this.PrivateAircraft = PrivateAircraft;
    }

    public void setPublicAircraft(ArrayList PublicAircraft) {
        this.PublicAircraft = PublicAircraft;
    }

    public void setAirport(ArrayList Airport) {
        this.Airport = Airport;
    }

    public void setFirstClassTicket(ArrayList FirstClassTicket) {
        this.FirstClassTicket = FirstClassTicket;
    }

    public void setBusinessTicket(ArrayList BusinessTicket) {
        this.BusinessTicket = BusinessTicket;
    }

    public void setEconomyTicket(ArrayList EconomyTicket) {
        this.EconomyTicket = EconomyTicket;
    }
    
    public void addPassenger(Passenger P) {
        Passenger.add(P);
    }
    public void addEmployee(Employee E) {
        Employee.add(E);
    }
    public void addFlight(Flight F) {
        Flight.add(F);
    }
    public void addPrivateAircraft(PrivateAircraft P) {
        PrivateAircraft.add(P);
    }
    public void addPublicAircraft(PublicAircraft P) {
        PublicAircraft.add(P);
    }
    public void addAirport(Airport A) {
        Airport.add(A);
    }
    public void addFirstClassTicket(FirstClassTicket F) {
        FirstClassTicket.add(F);
    }
    public void addBusinessTicket(BusinessTicket B) {
        BusinessTicket.add(B);
    }
    public void addEconomyTicket(EconomyTicket E) {
        EconomyTicket.add(E);
    }
}
