/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.airlinebookingsystem;

/**
 *
 * @author mahmoudkalmasidi
 */
public class PublicAircraft extends Aircraft implements AirlineBooking {
    private String TripType;

    public PublicAircraft(String TripType, String type, int capacity, int averageSpeed, String model, int fuelLevel, boolean engineRunning) {
        super(type, capacity, averageSpeed, model, fuelLevel, engineRunning);
        this.TripType = TripType;
    }

    public String getTripType() {
        return TripType;
    }

    public void setTripType(String TripType) {
        this.TripType = TripType;
    }

    @Override
    public void viewDetails() {
        System.out.println("Aircraft model : " + getModel());
        System.out.println("Aircraft Capacity : " + getCapacity());
        System.out.println("Aircraft Average Speed : " + getAverageSpeed());
        System.out.println("Aircraft Trip Type : " + TripType);
    }
    
    
}
