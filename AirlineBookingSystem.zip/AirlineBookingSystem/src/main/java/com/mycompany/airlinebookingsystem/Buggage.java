/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.airlinebookingsystem;

/**
 *
 * @author mahmoudkalmasidi
 */
public class Buggage {
    private int BuggageId;
    private int PassengerNumber;
    private double Weight;
    private double Length;
    private double Width;
    private double Height;

    public Buggage(int BuggageId, int PassengerNumber, double Weight, double Length, double Width, double Height) {
        this.BuggageId = BuggageId;
        this.PassengerNumber = PassengerNumber;
        this.Weight = Weight;
        this.Length = Length;
        this.Width = Width;
        this.Height = Height;
    }

    public int getBuggage() {
        return BuggageId;
    }

    public void setBuggage(int BuggageId) {
        this.BuggageId = BuggageId;
    }

    public int getPassengerNumber() {
        return PassengerNumber;
    }

    public void setPassengerNumber(int PassengerNumber) {
        this.PassengerNumber = PassengerNumber;
    }

    public double getWeight() {
        return Weight;
    }

    public void setWeight(double Weight) {
        this.Weight = Weight;
    }

    public double getLength() {
        return Length;
    }

    public void setLength(double Length) {
        this.Length = Length;
    }

    public double getWidth() {
        return Width;
    }

    public void setWidth(double Width) {
        this.Width = Width;
    }

    public double getHeight() {
        return Height;
    }

    public void setHeight(double Height) {
        this.Height = Height;
    }
    
    public void calculateVolume() {
        double x = Length*Width*Height;
        System.out.println("The value of volume = " + x);
    }
    public void calculateCost() {
        System.out.println("The cost : " + (Width*2.5));
    }
    public void isOversized() {
        if(Length > 100 || Width > 100 || Height > 100)
            System.out.println("The buggage is oversized.");
        else
            System.out.println("The buggage is not oversized.");
    }
}
