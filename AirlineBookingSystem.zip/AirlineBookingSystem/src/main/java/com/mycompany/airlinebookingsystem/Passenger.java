/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.airlinebookingsystem;
import java.util.ArrayList; 
/**
 *
 * @author mahmoudkalmasidi
 */
public class Passenger extends Person implements AirlineBooking {
    private String username;
    private String password;
    private String PassportNumber;
    private ArrayList Book = new ArrayList<Booking>();
    static ArrayList Passengers = new ArrayList<Passenger>();
    private ArrayList PaymentB = new ArrayList<BankTransfer>();
    private ArrayList PaymentC = new ArrayList<CreditCard>();

    public Passenger(){}
    
    public Passenger(String username, String password) {
        this.username = username;
        this.password = password; 
    }
    
    public Passenger(String PassportNumber, String Name, String Gender, String Nationality, String BirthDate, int Age) {
        super(Name, Gender, Nationality, BirthDate, Age);
        this.PassportNumber = PassportNumber;
    }

    public Passenger(String Name, String Gender, String Nationality, String BirthDate, int Age) {
        super(Name, Gender, Nationality, BirthDate, Age);
    }
    

    public void setPassportNumber(String PassportNumber) {
        this.PassportNumber = PassportNumber;
    }
    
    public void setUsername(String username) {
        this.username = username;
    }
    
    public String getUsername() {
        return username;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    public String  getPassword() {
        return password;
    }

    public void setBook(ArrayList Book) {
        this.Book = Book;
    }

    public void setPaymentB(ArrayList PaymentB) {
        this.PaymentB = PaymentB;
    }

    public void setPaymentC(ArrayList PaymentC) {
        this.PaymentC = PaymentC;
    }

    public String getPassportNumber() {
        return PassportNumber;
    }

    public ArrayList getBook() {
        return Book;
    }

    public ArrayList getPaymentB() {
        return PaymentB;
    }

    public ArrayList getPaymentC() {
        return PaymentC;
    }
    
    @Override
    public void viewDetails() {
        System.out.println("Passenger Name : " + getName());
        System.out.println("Passenger Gender : " + getGender());
        System.out.println("Passenger Nationality : " + getNationality());
        System.out.println("Passenger BirthDate : " + getBirthDate());
        System.out.println("Passenger Age : " + getAge());
        System.out.println("Passenger Passport Number : " + PassportNumber);
    }
    
    public void cancelFlight(String id) {
        Book.remove(id);
    }
    
    public void bookFlight(Booking b) {
        Book.add(b);
    }
    
    public void bookedFlight() {
        getBook();
    }
    
    
    public void updateAccount(String PassportNumber, String Name, String Gender, String Nationality, String BirthDate, int Age) {
        setName(Name);
        setGender(Gender);
        setNationality(Nationality);
        setBirthDate(BirthDate);
        setAge(Age);
        this.PassportNumber = PassportNumber;
        System.out.println("Passenger details updated successfully.");
    }
    
    public void makeComplaint(String c) {
        System.out.println("Complaint registered : " + c);
    }
    
    public void makeBankTransferPayment(BankTransfer b) {
        PaymentB.add(b);
    }
    
    public void makeCreditCardPayment(CreditCard c) {
        PaymentC.add(c);
    }
    
    public void ticketDetails(Booking b) { 
       b.viewDetails();
    }
    
    public static void createAccount(Passenger p) {
        Passengers.add(p);
    }
    public static Passenger login (String name, String pass)
    {
        Passenger P = null;
        for (int i=0; i < Passengers.size(); i++)
        { 
            P = (Passenger) Passengers.get(i);
            if (P.getUsername().equals(name) && P.getPassword().equals(pass))
                return P;
        }
        return null;
    }
}
