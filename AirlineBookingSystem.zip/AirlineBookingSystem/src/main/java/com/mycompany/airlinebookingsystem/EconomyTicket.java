/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.airlinebookingsystem;
import java.util.ArrayList;
/**
 *
 * @author mahmoudkalmasidi
 */
public class EconomyTicket extends Booking implements AirlineBooking {
    private int BaggageCount;
    private ArrayList Snack = new ArrayList<String>();
    private boolean SeatUpgrade;

    public EconomyTicket(int BaggageCount, String BookingID, int FlightNumber, String PassengerPassportNumber, String PassengerName, int SeatNumber, String DepartureTime, String ArrivalTime, String DepartureCity, String ArrivalCity, String TicketClass, int seatCount) {
        super(BookingID, FlightNumber, PassengerPassportNumber, PassengerName, SeatNumber, DepartureTime, ArrivalTime, DepartureCity, ArrivalCity, TicketClass, seatCount);
        this.BaggageCount = BaggageCount;
    }

    public int getBaggageCount() {
        return BaggageCount;
    }

    public void setBaggageCount(int BaggageCount) {
        this.BaggageCount = BaggageCount;
    }

    public ArrayList getSnack() {
        return Snack;
    }

    public void setSnack(ArrayList Snack) {
        this.Snack = Snack;
    }
    
    public void ticketType() {
        System.out.println("Economy Ticket.");
    }
    public void addSnack(String s) {
        Snack.add(s);
    }
    public void requestSeatUpgrade() {
        System.out.println("Your request has been executed.");
        SeatUpgrade = true;
    }
}
